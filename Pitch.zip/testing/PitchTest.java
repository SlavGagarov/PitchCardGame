import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class PitchTest {

	//check if the correct number of players are created
	@Test
	void playerNum() {
		Pitch game=new Pitch(3);
		int size=game.players.size();
		assertEquals(3,size);
	}

	//check if startRound resets play roundScore
	@Test
	void resetScore()
	{
		Pitch game=new Pitch(3);
		game.startRound();
		int s=game.players.get(0).roundScore;
		assertEquals(0,s);
	}
	
	//check for winner if a player has 7 points
	@Test
	void checkWinner()
	{
		Pitch game=new Pitch(3);
		game.players.get(0).score=7;
		assertEquals(true,game.checkForWinner());
	}
	
	//check for winner if no player has 7 or more points
	@Test
	void checkWinner2()
	{
		Pitch game=new Pitch(3);
		game.players.get(0).score=1;
		game.players.get(1).score=2;
		game.players.get(2).score=3;
		assertEquals(false,game.checkForWinner());
	}
	
	//check if score is updated correctly
	@Test
	void checkScoreCalc()
	{
		Pitch game=new Pitch(3);
		game.currentBet='S';
		game.players.get(0).wonCards.add(new Card(10,'S'));
		game.calcScore();
		assertEquals(0,game.players.get(1).score);
	}
}
