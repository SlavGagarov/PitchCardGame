import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class DeckTest {

	//test if size is correct when deck is made
	@Test
	void deckConstructorSize() {
		Deck d= new Deck();
		int s=d.getSize();
		assertEquals(52,s);
	}
	
	//test if size is c after pop
	@Test
	void popSize()
	{
		Deck d=new Deck();
		d.pop();
		int s=d.getSize();
		assertEquals(51,s);			
	}
	
	//test if size is c after push
	@Test
	void pushSize()
	{
		Deck d=new Deck();
		Card temp=new Card(2,'H');
		d.push(temp);
		int s=d.getSize();
		assertEquals(53,s);	
		
	}
	//test if size is c after a combination of pop and push
	@Test
	void pushPopSize()
	{
		Deck d=new Deck();
		Card temp=new Card(2,'H');
		for(int i=0;i<10;i++)
		{
			d.pop();
		}
		
		for(int i=0;i<18;i++)
		{
			d.push(temp);
		}
		
		for(int i=0;i<3;i++)
		{
			d.pop();
		}
		int s=d.getSize();
		assertEquals(57,s);
	}
	
	//check if the card on the top of the deck is correct after the deck is made
	@Test
	void topDeck()
	{
		Deck d=new Deck();
		Card temp = new Card(14,'D');
		String a=(temp.getSuit()+""+temp.getVal());
		Card top=d.pop();
		String b=(top.getSuit()+""+top.getVal());
		assertEquals(a,b);
	}

}
