import static org.junit.Assert.assertEquals;

import org.junit.Assert;
import org.junit.Test;
public class CardTest {

	//test suit
	@Test
    public void constructorSuit() {
        Card temp=new Card(5,'H');
        char suit=temp.getSuit();
        assertEquals('H',suit);

    }
	
	//test value
	@Test
    public void constructorVal() {
        Card temp=new Card(5,'H');
        int suit=temp.getVal();
        assertEquals(5,suit);

    }
	
	//test value > 10
	@Test
    public void constructorBigVal() {
        Card temp=new Card(11,'D');
        int suit=temp.getVal();
        assertEquals(11,suit);

    }
    
    //test print
	@Test
    public void printTest() {
        Card temp=new Card(2,'D');
        String suit="2 Diamonds ";
        assertEquals(suit,temp.print());

    }
	
	//test print for >10
	@Test
    public void printBigTest() {
        Card temp=new Card(13,'S');
        String suit="K Spades ";
        assertEquals(suit,temp.print());

    }
}
