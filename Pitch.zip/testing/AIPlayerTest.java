import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class AIPlayerTest {

	//check if score is correct when AIPlayer is constructed
	@Test
	void costScore() {
		AIPlayer p=new AIPlayer();
		int score=p.getScore();
		assertEquals(0,score);
	}
	
	//check if handsize is correct when AIPlayer is constructed
	@Test
	void costHandSize() {
		AIPlayer p=new AIPlayer();
		int size=p.handSize;
		assertEquals(0,size);
	}
	
	//check if AIPlayer decides the correct suit with 1 card in hand
	@Test
	void suitTest()
	{
		AIPlayer p=new AIPlayer();
		Card c=new Card(2,'H');
		p.hand.add(c);
		char char1='H';
		char char2=p.decideBetSuit();
		assertEquals(char1,char2);
	}
	
	//check if AIPlayer returns suit of higher value card when betting a suit
		@Test
		void highSuit()
		{
			AIPlayer p=new AIPlayer();
			Card c=new Card(10,'H');
			Card c2=new Card(2,'S');
			p.hand.add(c);
			p.hand.add(c2);
			char char1='H';
			char char2=p.decideBetSuit();
			assertEquals(char1,char2);
		}
		
	//check if AIPlayer plays higher card when its first turn
		@Test
		void playTestCard()
		{
			AIPlayer p=new AIPlayer();
			Pitch game=new Pitch(2);
			game.currentBet='S';
			Card c=new Card(2,'S');
			Card c2=new Card(10,'S');
			p.hand.add(c);
			p.hand.add(c2);
			Card carrd=p.decidePlay(game);
			assertEquals(carrd.getVal(),10);
		}
}
