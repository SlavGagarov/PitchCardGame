import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.hamcrest.CoreMatchers.*;

import org.junit.jupiter.api.Test;

class PitchDealerTest {

	//check if deck is correctly shuffled when after creation of PitchDealer
	//check if the bottom 4 cards of the deck are not the 2s(that is how unshuffled deck is created)
	//This case may fail very rarely(only when all 4 2s are on the bottom of the deck after shuffle)
	@Test
	void deckConstructor() {
		PitchDealer p = new PitchDealer();
		int check1=0;
		int check2=0;
		int check3=0;
		int check4=0;
		if(p.pitchDeck.deck.get(0).getVal()==2)
			check1=1;
		if(p.pitchDeck.deck.get(1).getVal()==2)
			check2=1;
		if(p.pitchDeck.deck.get(2).getVal()==2)
			check3=1;
		if(p.pitchDeck.deck.get(3).getVal()==2)
			check4=1;
		int checkSum=check1+check2+check3+check4;
		assertThat(4,is(not(checkSum)));
	}
	
	//test if deal returns 6 cards
	@Test
	void testDealSize()
	{
		PitchDealer p = new PitchDealer();
		ArrayList<Card> hand=p.dealHand();
		assertEquals(6,hand.size());
	}
	
	//Test if top card in the deck is the first card in the hand after the hand is dealt
	@Test
	void testFirst()
	{
		PitchDealer p = new PitchDealer();
		String top=p.pitchDeck.deck.get(p.pitchDeck.deck.size()-1).print();
		ArrayList<Card> hand=p.dealHand();
		String handF=hand.get(0).print();
		assertEquals(handF,top);
	}
	
	//Test if all 6 cards are the same
	@Test
	void wholeHand()
	{
		String top="";
		PitchDealer p = new PitchDealer();
		for(int i=0;i<6;i++)
			top+=p.pitchDeck.deck.get(p.pitchDeck.deck.size()-(i+1)).print();
		
		ArrayList<Card> hand=p.dealHand();
		String handF="";
		for(int i=0;i<6;i++)
			handF+=hand.get(i).print();
		assertEquals(handF,top);
	}
	
	//Test if deck size is correctly tracked after 4 dealt hands of 6 cards each
	@Test
	void dealFour()
	{
		PitchDealer p = new PitchDealer();
		for(int i=0;i<4;i++)
			p.dealHand();
		assertEquals(28,p.pitchDeck.getSize());
	}
}
