import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class PlayerTest {

	//check if score is correct when player is constructed
	@Test
	void costScore() {
		Player p=new Player();
		int score=p.getScore();
		assertEquals(0,score);
	}
	
	//check if handsize is correct when player is constructed
	@Test
	void costHandSize() {
		Player p=new Player();
		int size=p.handSize;
		assertEquals(0,size);
	}
	
	//check if hand size correctly updates when card is played
	@Test
	void playTest() {
		Player p=new Player();
		p.handSize=1;
		Card c= new Card(2,'H');
		p.hand.add(c);
		p.playCard(c);
		int size=p.handSize;
		assertEquals(0,size);
	}
	
	//check if null is returned if no cards in hand
	@Test
	void nullHand() {
		Player p=new Player();
		Card c= new Card(2,'H');
		Card temp=p.playCard(c);
		assertEquals(null,temp);
	}
	
	//check if null is returned if card not in hand
	@Test
	void playNull() {
		Player p=new Player();
		Card c= new Card(2,'H');
		p.hand.add(c);
		Card temp=p.playCard(new Card(10,'H'));
		assertEquals(null,temp);
	}
}
