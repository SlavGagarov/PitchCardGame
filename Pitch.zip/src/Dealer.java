import java.util.*;
public interface Dealer {
	public ArrayList<Card> dealHand();

}
