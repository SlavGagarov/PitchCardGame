
public interface DealerType {
	public Dealer createDealer();
}
